import random

actualNum = random.randint(1, 100)
print("Higher or Lower Guessing game\n-----")
guessNum = 0
numOfGuesses = -1

while guessNum != actualNum:
    guessNum = input("Guess a number 1-100. \n")
    numOfGuesses += 1
    if int(guessNum) > 100:
        print("Guess a number that is under 100.")
    elif int(guessNum) < 1:
        print("Guess a number that is over 0.")
    elif int(guessNum) > int(actualNum):
        print("Too high\n-----")
    elif int(guessNum) < int(actualNum):
        print("Too low\n-----")
    elif int(guessNum) == int(actualNum):
        numOfGuesses += 1
        print("You got it! The number was " + str(actualNum))
        print("\nYou figured it out in " + str(numOfGuesses) + " guesses!")
        break
    else:
        break
